package csbst.testing;

import java.util.Vector;

public class UnitUnderTest
{
  private Vector<ClassUnderTest> classesUnderTest;
}


/* Location:              E:\JTExpert\JTExpert-1.2.jar!\csbst\testing\UnitUnderTest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package csbst.heuristic;

import java.util.Set;

public abstract interface Heuristic
{
  public abstract int run(Set<Integer> paramSet);
}


/* Location:              E:\JTExpert\JTExpert-1.2.jar!\csbst\heuristic\Heuristic.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
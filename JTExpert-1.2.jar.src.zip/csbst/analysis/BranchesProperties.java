package csbst.analysis;

public class BranchesProperties
{
  public static final String NUM_BRANCH = "numberBranch";
  public static final String EXPRESSION = "expression";
  public static final String NUM_PARENT_BRANCH = "numberParentBranch";
  public static final String IS_MULTIBRANCHES_ROOT = "isMultiBranchesRoot";
  public static final String METHOD_CONTAINER = "methodContainer";
  public static final String INFLUENCERS = "influencers";
  public static final String DIFF_COEF = "difficultyCoefficient";
}


/* Location:              E:\JTExpert\JTExpert-1.2.jar!\csbst\analysis\BranchesProperties.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
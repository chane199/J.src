package csbst.analysis;

public enum DataMemberUsage
{
  Read,  Report,  Transform,  Other;
}


/* Location:              E:\JTExpert\JTExpert-1.2.jar!\csbst\analysis\DataMemberUsage.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */
package csbst.utils;

public abstract interface IApp
{
  public abstract void start();
  
  public abstract void shutDown();
}


/* Location:              E:\JTExpert\JTExpert-1.2.jar!\csbst\utils\IApp.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */